from fpdf import FPDF
from html import HTMLMixin
from template import Template


